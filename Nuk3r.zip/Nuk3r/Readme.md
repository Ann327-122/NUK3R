HI!

Okay, so, 'NUK3R' (Nuker) is a 4AM Power-trip and curiosity induced nightmaresoftware,

It has Zero stops, safety protocols, or confirmation dialogs, so be CAREFUL.

and I hate Microsofts BloatBrowser so I've added a bunch of commands to irradicate it-
as best as I can using C.. I'm not very good at C, I'm best at Java and stuff.
But I didn't want to use python, ... and I'm not sure if you can create a CMD window with java...



CREDITS:

ICON: ME
CODE: ME

HEADACHES: ME & THE CODE & cl.exe

Just so you can actually see it's NOT a virus or malware, *Which I understand if you think it is lol.. There is no safety stuff what-so-ever.
I've included my terrible source code, (Nuk3r.c) and the commands for compiling, (Nuk3r.rc + compcmd.txt)

---
"Proffesional" Description down here so github actually looks presentable:
---

# NUK3R - Advanced System Administration Utility

NUK3R is a open-source Command Line Interface (CLI) tool designed for aggressive system maintenance and bloatware managment. Written purely in C, it offers administators a lightweight solution for rapid task termination and file system cleanup without the hinderance of user-safety confirmations or latency.

**Core Capabilties:**

*   **Process Control:** Leverages Windows APIs to force-terminate running tasks and handles instantley.
*   **File System Operations:** Performs recursive directory deletions and file removal with high priority.
*   **Package Managment:** Integrates with `winget` to streamline application uninstallation from the console.
*   **Edge Mitigation:** Contains specific logic routenes dedicated to the detection and removal of Microsoft Edge components and services.

**Disclaimer:**
This software is provided "as is" with absolutely no warranty. It is a powerful tool capable of irreversable changes to the operating system. The developer (Ann) takes zero responsibility for system instability, data loss, or accidental self-destruction of you're windows install.

*Please run as Administrator for full functionality.*